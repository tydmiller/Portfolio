/*
File: GameObjectManager.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from GameObjectManager.h and implements functions that
Updates the game object manager, shutdowns the game object manager, unloads the game object manager, add object,
add archetype, gets object by name, gets archetype by name, get object count, variable update,
fixed updates, destory objects, and draw
*/
#include "stdafx.h"
#include "GameObjectManager.h"
#include "GameObject.h"
#include "Space.h"
#include "Collider.h"

GameObjectManager::GameObjectManager(Space * space)
	: BetaObject("ObjectManager", space), numObjects(0), numArchetypes(0), fixedUpdateDt(1.f/60.f), timeAccumulator(0)
{
}

GameObjectManager::~GameObjectManager()
{
	Shutdown();
	Unload();
}

void GameObjectManager::Update(float dt)
{
	if (static_cast<Space*>(GetParent())->IsPaused() == false)
	{
		VariableUpdate(dt);
		FixedUpdate(dt);
	}
	DestroyObjects();
	Draw();
}

void GameObjectManager::Shutdown(void)
{
	for (unsigned int i = 0; i < numObjects; i++)
	{
		delete gameObjectActiveList[i];
	}
	numObjects = 0;
}

void GameObjectManager::Unload(void)
{
	for (unsigned int i = 0; i < numArchetypes; i++)
	{
		delete gameObjectArchetypes[i];
	}
	numArchetypes = 0;
}

void GameObjectManager::AddObject(GameObject & gameObject)
{
	gameObject.SetParent(GetParent());
	gameObject.Initialize();
	gameObjectActiveList[numObjects] = &gameObject;
	numObjects += 1;
}

void GameObjectManager::AddArchetype(GameObject & gameObject)
{
	gameObjectArchetypes[numArchetypes] = &gameObject;
	numArchetypes += 1;
}

GameObject * GameObjectManager::GetObjectByName(const std::string & objectName) const
{
	for (unsigned int i = 0; i < numObjects; i++)
	{
		if (gameObjectActiveList[i]->GetName() == objectName)
		{
			return gameObjectActiveList[i];
		}
	}
	return nullptr;
}

GameObject * GameObjectManager::GetArchetypeByName(const std::string & objectName) const
{
	for (unsigned int i = 0; i < numArchetypes; i++)
	{
		if (gameObjectArchetypes[i]->GetName() == objectName)
		{
			return gameObjectArchetypes[i];
		}
	}
	return nullptr;
}

unsigned GameObjectManager::GetObjectCount(const std::string & objectName) const
{
	unsigned int gameObjectCount = 0;
	for (unsigned int i = 0; i < numObjects; i++)
	{
		if (gameObjectActiveList[i]->GetName() == objectName && gameObjectActiveList[i]->IsDestroyed() == false)
		{
			gameObjectCount += 1;
		}
	}
	return gameObjectCount;
}

void GameObjectManager::VariableUpdate(float dt)
{
	for (unsigned int i = 0; i < numObjects; i++)
	{
		if (gameObjectActiveList[i] != nullptr)
		{
			gameObjectActiveList[i]->Update(dt);
		}
	}
}

void GameObjectManager::FixedUpdate(float dt)
{
	timeAccumulator += dt;
	while (timeAccumulator >= dt)
	{
		for (unsigned int i = 0; i < numObjects; i++)
		{
			gameObjectActiveList[i]->FixedUpdate(fixedUpdateDt);
		}
		timeAccumulator -= fixedUpdateDt;
		CheckCollisions();
	}
}

void GameObjectManager::DestroyObjects()
{
	for (unsigned int i = 0; i < numObjects; i++)
	{
		if (gameObjectActiveList[i]->IsDestroyed() == true)
		{
			delete gameObjectActiveList[i];
			gameObjectActiveList[i] = gameObjectActiveList[numObjects - 1];
			gameObjectActiveList[numObjects - 1] = nullptr;
			numObjects -= 1;
		}
	}
}

void GameObjectManager::Draw(void)
{
	for (unsigned int i = 0; i < numObjects; i++)
	{
		if (gameObjectActiveList[i] != nullptr)
		{
			gameObjectActiveList[i]->Draw();
		}
	}
}

void GameObjectManager::CheckCollisions()
{
	for (unsigned int i = 0; i < numObjects; i++)
	{
		Collider* gameObjectInList = static_cast<Collider*>(gameObjectActiveList[i]->GetComponent("Collider"));
		if (gameObjectActiveList[i]->IsDestroyed() == true)
		{
			return;
		}
		if (gameObjectInList == nullptr)
		{
			return;
		}
		for (unsigned int u = i + 1; u < numObjects; u++)
		{
			Collider* gameObjectInListSecond = static_cast<Collider*>(gameObjectActiveList[u]->GetComponent("Collider"));
			if (gameObjectActiveList[u]->IsDestroyed() == true)
			{
				return;
			}
			if (gameObjectInListSecond == nullptr)
			{
				return;
			}
			gameObjectInListSecond->CheckCollision(*gameObjectInList);
		}
	}
}
