/*
File: Level3.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Level3.h and implements functions that
loads the level, intializes the level, updates the level, initializes the level, loads the level, 
and unloads the level
*/

#include "stdafx.h"
#include "Level3.h"
#include "Level1.h"
#include "Level2.h"
#include "Platformer.h"
#include "MeshHelper.h"
#include "Texture.h"
#include "SpriteSource.h"
#include "Archetypes.h"
#include "GameObjectManager.h"
#include "Space.h"
#include "Input.h"
#include "Mesh.h"
#include "Physics.h"
#include "Transform.h"

Levels::Level3::Level3()
	: Level("Level3"), meshQuad(nullptr), spriteSourceCircle(nullptr), textureCircle(nullptr)
{
}

void Levels::Level3::Load()
{
	meshQuad = CreateQuadMesh(Vector2D(1, 1), Vector2D(0.5, 0.5));
	textureCircle = Texture::CreateTextureFromFile("Circle.png");
	spriteSourceCircle = new SpriteSource(1, 1, textureCircle);
}

void Levels::Level3::Initialize()
{
	GameObject* gameObjectPointerCircle = nullptr;
	GameObject* gameObjectPointerCircle2 = nullptr;
	GameObject* gameObjectPointerPoint = nullptr;
	GameObject* gameObjectPointerRectangle = nullptr;
	GameObject* gameObjectPointerRectangle2 = nullptr;
	gameObjectPointerCircle = Archetypes::CreateCircle(meshQuad, spriteSourceCircle);
	gameObjectPointerCircle2 = Archetypes::CreateCircle(meshQuad, spriteSourceCircle);
	static_cast<Physics*>(gameObjectPointerCircle2->GetComponent("Physics"))->SetVelocity(Vector2D(0, 200));
	gameObjectPointerPoint = Archetypes::CreatePoint(meshQuad, spriteSourceCircle);
	static_cast<Physics*>(gameObjectPointerPoint->GetComponent("Physics"))->SetVelocity(Vector2D(0, -200));
	gameObjectPointerRectangle = Archetypes::CreateRectangle(meshQuad);
	static_cast<Physics*>(gameObjectPointerRectangle->GetComponent("Physics"))->SetVelocity(Vector2D(200, 200));
	gameObjectPointerRectangle2 = Archetypes::CreateRectangle(meshQuad);
	static_cast<Transform*>(gameObjectPointerRectangle2->GetComponent("Transform"))->SetTranslation(Vector2D(-100, 150));
	static_cast<Physics*>(gameObjectPointerRectangle2->GetComponent("Physics"))->SetVelocity(Vector2D(250, 0));
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerCircle);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerCircle2);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerPoint);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerRectangle);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerRectangle2);
}

void Levels::Level3::Update(float dt)
{
	UNREFERENCED_PARAMETER(dt);
	if (Input::GetInstance().CheckTriggered('1'))
	{
		GetSpace()->SetLevel(new Level1);
	}
	else if (Input::GetInstance().CheckTriggered('2'))
	{
		GetSpace()->SetLevel(new Level2);
	}
	else if (Input::GetInstance().CheckTriggered('3'))
	{
		GetSpace()->RestartLevel();
	}
	else if (Input::GetInstance().CheckTriggered('4'))
	{
		GetSpace()->SetLevel(new Platformer);
	}
}

void Levels::Level3::Unload()
{
	delete meshQuad;
	delete textureCircle;
	delete spriteSourceCircle;
}
