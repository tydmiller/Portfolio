/*
File: MeshHelper.cpp
Name: Tyler Miller
Course: CS230
Date: 10-31-18
Description: This implements the functions from MeshHelper.h and implements functions that
creates a triangle mesh and a quad mesh
*/
#include "stdafx.h"
#include "MeshHelper.h"
#include "MeshFactory.h"
#include <Vertex.h>

Mesh * CreateTriangleMesh(const Color & color0, const Color & color1, const Color & color2)
{
	MeshFactory::GetInstance().AddTriangle(Vertex(Vector2D(-0.5, 0.5), color1), Vertex(Vector2D(-0.5, -0.5), color0), Vertex(Vector2D(0.5, 0), color2));
	Mesh* triangleMesh = MeshFactory::GetInstance().EndCreate();
	return triangleMesh;
}

Mesh * CreateQuadMesh(const Vector2D & textureSize, const Vector2D & extents)
{
	Vertex topLeft = Vertex(Vector2D(-extents.x, extents.y), Vector2D(0, 0));
	Vertex bottomLeft = Vertex(Vector2D(-extents.x, -extents.y), Vector2D(0, textureSize.y));
	Vertex bottomRight = Vertex(Vector2D(extents.x, -extents.y), Vector2D(textureSize.x, textureSize.y));
	Vertex topRight = Vertex(Vector2D(extents.x, extents.y), Vector2D(textureSize.x, 0));
	MeshFactory::GetInstance().AddTriangle(topLeft, bottomLeft, bottomRight);
	MeshFactory::GetInstance().AddTriangle(topLeft, topRight, bottomRight);
	Mesh* quadMesh = MeshFactory::GetInstance().EndCreate();
	return quadMesh;
}
