/*
File: Intersection2D.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from ColliderPoint.h and implements functions that
check the collision between a point and a circle, point and rectangle, circle and circle,
rectangle and rectangle, rectangle and circle
*/
#include "stdafx.h"
#include "Intersection2D.h"
#include "Vector2D.h"

bool PointCircleIntersection(const Vector2D & point, const Circle & circle)
{
	float distance = circle.center.Distance(point);
	if (distance <= circle.radius)
	{
		return true;
	}
	return false;
}

bool PointRectangleIntersection(const Vector2D & point, const BoundingRectangle & rect)
{
	if (point.y <= rect.top && point.y >= rect.bottom && point.x >= rect.left && point.x <= rect.right)
	{
		return true;
	}
	return false;
}

bool CircleCircleIntersection(const Circle & circle1, const Circle & circle2)
{
	float distance = circle1.center.Distance(circle2.center);
	if (distance <= circle1.radius + circle2.radius)
	{
		return true;
	}
	return false;
}

bool RectangleRectangleIntersection(const BoundingRectangle & rect1, const BoundingRectangle & rect2)
{
	if (rect1.right < rect2.left)
	{
		return false;
	}
	if (rect1.top < rect2.bottom)
	{
		return false;
	}
	if (rect1.left > rect2.right)
	{
		return false;
	}
	if (rect1.bottom > rect2.top)
	{
		return false;
	}
	return true;
}

bool RectangleCircleIntersection(const BoundingRectangle & rect, const Circle & circle)
{
	Vector2D newPoint = circle.center;
	if (circle.center.x > rect.right)
	{
		newPoint.x = rect.right;
	}
	else if (circle.center.x < rect.left)
	{
		newPoint.x = rect.left;
	}
	if (circle.center.y > rect.top)
	{
		newPoint.y = rect.top;
	}
	else if (circle.center.y < rect.bottom)
	{
		newPoint.y = rect.bottom;
	}
	float distance = newPoint.Distance(circle.center);
	if (distance <= circle.radius)
	{
		return true;
	}
	else
	{
		return false;
	}
}
