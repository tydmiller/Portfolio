/*
File: Archetypes.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Archetypes.h and implements functions that
creates the ship, Creates the bullet archetype, and creates the monkey, creates circle,
creates points, creates rectangle, and creates tilemap
*/
#include "stdafx.h"
#include "Archetypes.h"
#include "GameObject.h"
#include "Transform.h"
#include "Sprite.h"
#include "SpriteSource.h"
#include "Physics.h"
#include "PlayerShip.h"
#include "TimedDeath.h"
#include "Animation.h"
#include "MonkeyMovement.h"
#include "Collider.h"
#include "ColliderTilemap.h"
#include "ColliderCircle.h"
#include "ColliderPoint.h"
#include "ColliderRectangle.h"
#include "ColorChange.h"
#include "ScreenWrap.h"
#include "SpriteTilemap.h"
#include "Enemy.h"

GameObject * Archetypes::CreateShip(Mesh * mesh)
{
	GameObject* ship = new GameObject("Ship");
	Transform* transform = new Transform(Vector2D(0, 0), Vector2D(50, 50), 0.f);
	Sprite* sprite = new Sprite();
	Physics* physics = new Physics();
	Behaviors::PlayerShip* playerShip = new Behaviors::PlayerShip(100.f, 100.f, static_cast<float>(M_PI), 200.f);
	sprite->SetMesh(mesh);
	ship->AddComponent(transform);
	ship->AddComponent(sprite);
	ship->AddComponent(physics);
	ship->AddComponent(playerShip);
	return ship;
}

GameObject * Archetypes::CreateBulletArchetype(Mesh * mesh)
{
	GameObject* bullet = new GameObject("bullet");
	Transform* transform = new Transform(Vector2D(0, 0), Vector2D(7, 7), 0.f);
	Sprite* sprite = new Sprite();
	Physics* physics = new Physics();
	Behaviors::TimedDeath* timedDeath = new Behaviors::TimedDeath(3.f);
	sprite->SetMesh(mesh);
	bullet->AddComponent(transform);
	bullet->AddComponent(sprite);
	bullet->AddComponent(physics);
	bullet->AddComponent(timedDeath);
	return bullet;
}

GameObject * Archetypes::CreateMonkey(Mesh * mesh, SpriteSource * spriteSource)
{
	GameObject* monkey = new GameObject("monkey");
	Transform* transform = new Transform(Vector2D(0, 0), Vector2D(100, 100), 0.f);
	Sprite* sprite = new Sprite();
	Animation* animation = new Animation();
	Physics* physics = new Physics();
	ColliderRectangle* colliderRectangle = new ColliderRectangle(transform->GetScale() / 2);
	Behaviors::MonkeyMovement* monkeyMovement = new Behaviors::MonkeyMovement();
	sprite->SetMesh(mesh);
	sprite->SetSpriteSource(spriteSource);
	monkey->AddComponent(transform);
	monkey->AddComponent(sprite);
	monkey->AddComponent(animation);
	monkey->AddComponent(physics);
	monkey->AddComponent(monkeyMovement);
	monkey->AddComponent(colliderRectangle);
	return monkey;
}

GameObject * Archetypes::CreateCircle(Mesh * mesh, SpriteSource * spriteSource)
{
	GameObject* circle = new GameObject("circle");
	Transform* transform = new Transform(Vector2D(0, 0), Vector2D(100, 100), 0.f);
	Sprite* sprite = new Sprite();
	Physics* physics = new Physics();
	ColliderCircle* colliderCircle = new ColliderCircle();
	Behaviors::ColorChange* colorChange = new Behaviors::ColorChange(Colors::Yellow, Colors::Red);
	Behaviors::ScreenWrap* screenWrap = new Behaviors::ScreenWrap();
	sprite->SetMesh(mesh);
	sprite->SetSpriteSource(spriteSource);
	circle->AddComponent(transform);
	circle->AddComponent(sprite);
	circle->AddComponent(physics);
	circle->AddComponent(colliderCircle);
	circle->AddComponent(colorChange);
	circle->AddComponent(screenWrap);
	return circle;
}

GameObject * Archetypes::CreatePoint(Mesh * mesh, SpriteSource * spriteSource)
{
	GameObject* point = new GameObject("point");
	Transform* transform = new Transform(Vector2D(0, 100), Vector2D(20, 20), 0.f);
	Sprite* sprite = new Sprite();
	Physics* physics = new Physics();
	ColliderPoint* colliderPoint = new ColliderPoint();
	Behaviors::ColorChange* colorChange = new Behaviors::ColorChange(Colors::Blue, Colors::Red);
	Behaviors::ScreenWrap* screenWrap = new Behaviors::ScreenWrap();
	sprite->SetMesh(mesh);
	sprite->SetSpriteSource(spriteSource);
	point->AddComponent(transform);
	point->AddComponent(sprite);
	point->AddComponent(physics);
	point->AddComponent(colliderPoint);
	point->AddComponent(colorChange);
	point->AddComponent(screenWrap);
	return point;
}

GameObject * Archetypes::CreateRectangle(Mesh * mesh)
{
	GameObject* rectangle = new GameObject("rectangle");
	Transform* transform = new Transform(Vector2D(-200, 0), Vector2D(250, 100), 0.f);
	Sprite* sprite = new Sprite();
	Physics* physics = new Physics();
	ColliderRectangle* colliderRectangle = new ColliderRectangle(transform->GetScale() / 2);
	Behaviors::ColorChange* colorChange = new Behaviors::ColorChange(Colors::Green, Colors::Red);
	Behaviors::ScreenWrap* screenWrap = new Behaviors::ScreenWrap();
	sprite->SetMesh(mesh);
	rectangle->AddComponent(transform);
	rectangle->AddComponent(sprite);
	rectangle->AddComponent(physics);
	rectangle->AddComponent(colliderRectangle);
	rectangle->AddComponent(colorChange);
	rectangle->AddComponent(screenWrap);
	return rectangle;
}

GameObject * Archetypes::CreateTilemapObject(Mesh * mesh, SpriteSource * spriteSource, Tilemap * map)
{
	GameObject* tileMap = new GameObject("tileMap");
	Transform* transform = new Transform(Vector2D(-350, 250), Vector2D(100, 100), 0.f);
	SpriteTilemap* spriteTilemap = new SpriteTilemap();
	ColliderTilemap* colliderTilemap = new ColliderTilemap();
	spriteTilemap->SetMesh(mesh);
	spriteTilemap->SetSpriteSource(spriteSource);
	spriteTilemap->SetTilemap(map);
	colliderTilemap->SetTilemap(map);
	tileMap->AddComponent(transform);
	tileMap->AddComponent(spriteTilemap);
	tileMap->AddComponent(colliderTilemap);
	return tileMap;
}

GameObject * Archetypes::CreateCollectibleObject(Mesh * mesh, SpriteSource * spriteSource)
{
	GameObject* collectible = new GameObject("collectible");
	Transform* transform = new Transform(Vector2D(50, 50), Vector2D(50, 50), 0.f);
	Sprite* sprite = new Sprite();
	ColliderCircle* colliderCircle = new ColliderCircle();
	sprite->SetMesh(mesh);
	sprite->SetColor(Colors::Yellow);
	sprite->SetSpriteSource(spriteSource);
	collectible->AddComponent(transform);
	collectible->AddComponent(sprite);
	collectible->AddComponent(colliderCircle);
	return collectible;
}

GameObject * Archetypes::CreateEnemy(Mesh * mesh)
{
	GameObject* enemy = new GameObject("enemy");
	Transform* transform = new Transform(Vector2D(-150, 150), Vector2D(50, 50), 0.f);
	Sprite* sprite = new Sprite();
	ColliderRectangle* colliderRectangle = new ColliderRectangle();
	Physics* physics = new Physics();
	Behaviors::Enemy* enemyBehavior = new Behaviors::Enemy();
	sprite->SetMesh(mesh);
	sprite->SetColor(Colors::Red);
	enemy->AddComponent(transform);
	enemy->AddComponent(sprite);
	enemy->AddComponent(colliderRectangle);
	enemy->AddComponent(physics);
	enemy->AddComponent(enemyBehavior);
	return enemy;
}

GameObject * Archetypes::CreateHazard(Mesh * mesh)
{
	GameObject* hazard = new GameObject("hazard");
	Transform* transform = new Transform(Vector2D(-150, 150), Vector2D(50, 50), 0.f);
	Sprite* sprite = new Sprite();
	ColliderRectangle* colliderRectangle = new ColliderRectangle();
	Physics* physics = new Physics();
	sprite->SetMesh(mesh);
	sprite->SetColor(Colors::Orange);
	hazard->AddComponent(transform);
	hazard->AddComponent(sprite);
	hazard->AddComponent(colliderRectangle);
	hazard->AddComponent(physics);
	return hazard;
}
