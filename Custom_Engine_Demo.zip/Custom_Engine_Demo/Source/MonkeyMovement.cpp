/*
Name: Tyler Miller
File: MonkeyMovement.cpp
Date: 10-8-18
Course: CS230
Description: This file implements the MonkeyMovement, Clone, Initialize, Update,
Serialize, Deserialize, MoveHorizontal, MoveVertical, and the monkey collision handler
*/

#include "stdafx.h"
#include "MonkeyMovement.h"
#include "Physics.h"
#include "GameObject.h"
#include "Transform.h"
#include "Animation.h"
#include "Input.h"
#include "Collider.h"
#include "ColliderTilemap.h"
#include "Space.h"
#include "Platformer.h"

void Behaviors::MonkeyMapCollisionHandler(GameObject& object, const MapCollision& collision);
void Behaviors::MonkeyCollisionHandler(GameObject& object, GameObject& other);

Behaviors::MonkeyMovement::MonkeyMovement()
	: Component("MonkeyMovement"), monkeyJumpSpeed(monkeyJumpSpeed), monkeyWalkSpeed(monkeyWalkSpeed), gravity(gravity)
{
	monkeyWalkSpeed = 300.0f;
	monkeyJumpSpeed = 800.0f;
	gravity = Vector2D(0.0f, -1200.0f);
}

Component* Behaviors::MonkeyMovement::Clone() const
{
	return new MonkeyMovement(*this);
}

void Behaviors::MonkeyMovement::Initialize()
{
	transform = static_cast<Transform*>(GetOwner()->GetComponent("Transform"));
	physics = static_cast<Physics*>(GetOwner()->GetComponent("Physics"));
	static_cast<Animation*>(GetOwner()->GetComponent("Animation"))->Play(0, 7, 0.2f, true);
	static_cast<Collider*>(GetOwner()->GetComponent("Collider"))->SetMapCollisionHandler(MonkeyMapCollisionHandler);
	static_cast<Collider*>(GetOwner()->GetComponent("Collider"))->SetCollisionHandler(MonkeyCollisionHandler);
}

void Behaviors::MonkeyMovement::Update(float dt)
{
	UNREFERENCED_PARAMETER(dt);
	MonkeyMovement::MoveHorizontal();
	MonkeyMovement::MoveVertical();
}


void Behaviors::MonkeyMovement::MoveHorizontal() const
{
	Vector2D movement = physics->GetVelocity();
	if (Input::GetInstance().CheckHeld(VK_RIGHT))
	{
		movement.x = monkeyWalkSpeed;
		physics->SetVelocity(movement);
	}
	else if (Input::GetInstance().CheckHeld(VK_LEFT))
	{
		movement.x = -monkeyWalkSpeed;
		physics->SetVelocity(movement);
	}
	else
	{
		movement.x = 0;
		physics->SetVelocity(movement);
	}
}

void Behaviors::MonkeyMovement::MoveVertical()
{
	Vector2D jump = physics->GetVelocity();
	Vector2D translation = transform->GetTranslation();
	if (onGround == true)
	{
		if (Input::GetInstance().CheckTriggered(VK_UP))
		{
			jump.y = monkeyJumpSpeed;
			physics->SetVelocity(jump);
			onGround = false;
		}
	}
	physics->AddForce(gravity);
	if (jump.y < -50)
	{
		onGround = false;
	}
}

void Behaviors::MonkeyMapCollisionHandler(GameObject & object, const MapCollision& collision)
{
	if (collision.bottom == true)
	{
		static_cast<MonkeyMovement*>(object.GetComponent("MonkeyMovement"))->onGround = true;
	}
}

void Behaviors::MonkeyCollisionHandler(GameObject & object, GameObject & other)
{
	if (object.GetName() == "monkey" && other.GetName() == "collectible")
	{
		other.Destroy();
	}
	if (object.GetName() == "monkey" && (other.GetName() == "enemy" || other.GetName() == "hazard"))
	{
		object.Destroy();
		object.GetSpace()->RestartLevel();
	}
}
