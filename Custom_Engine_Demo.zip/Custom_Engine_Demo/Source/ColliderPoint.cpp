/*
File: ColliderPoint.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from ColliderPoint.h and implements functions that
clones the collider point, draws collider point, and is colliding with collider point functions
*/
#include "stdafx.h"
#include "ColliderPoint.h"
#include "Space.h"
#include "DebugDraw.h"
#include "Graphics.h"
#include "Transform.h"
#include "Intersection2D.h"
#include "ColliderCircle.h"
#include "ColliderRectangle.h"

ColliderPoint::ColliderPoint()
	: Collider(ColliderTypePoint)
{
}

Component * ColliderPoint::Clone() const
{
	return new ColliderPoint(*this);
}

void ColliderPoint::Draw()
{
	DebugDraw& draw = DebugDraw::GetInstance();
	Graphics& graphics = Graphics::GetInstance();
	draw.AddCircle(transform->GetTranslation(), 10.f, graphics.GetDefaultCamera(), Colors::Green);
}

bool ColliderPoint::IsCollidingWith(const Collider & other) const
{
	if (other.GetType() == ColliderTypeCircle)
	{
		const ColliderCircle& otherCircle = static_cast<const ColliderCircle&>(other);
		return PointCircleIntersection(transform->GetTranslation(), Circle(static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation(), otherCircle.GetRadius()));
	}
	if (other.GetType() == ColliderTypeRectangle)
	{
		const ColliderRectangle& otherRectangle = static_cast<const ColliderRectangle&>(other);
		return PointRectangleIntersection(transform->GetTranslation(), BoundingRectangle(static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation(), otherRectangle.GetExtents()));
	}
	if (other.GetType() == ColliderTypePoint)
	{
		return false;
	}
	return false;
}
