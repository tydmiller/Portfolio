/*
File: ColorChange.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from ColorChange.h and implements functions that
clones the function, initializes the class, updates the color change, and calls color 
change collision handler
*/
#include "stdafx.h"
#include "ColorChange.h"
#include "Space.h"
#include "Sprite.h"
#include "Collider.h"

void Behaviors::ColorChangeCollisionHandler(GameObject& object, GameObject& other);

Behaviors::ColorChange::ColorChange(const Color & normalColor, const Color & collidedColor, float collidedColorTime)
	: Component("ColorChange"), normalColor(normalColor), collidedColor(collidedColor), collidedColorTime(collidedColorTime), collided(false)
{
}

Component * Behaviors::ColorChange::Clone() const
{
	return new ColorChange(*this);
}

void Behaviors::ColorChange::Initialize()
{
	sprite = static_cast<Sprite*>(GetOwner()->GetComponent("Sprite"));
	Collider* objectCollider = static_cast<Collider*>(GetOwner()->GetComponent("Collider"));
	objectCollider->SetCollisionHandler(ColorChangeCollisionHandler);
}

void Behaviors::ColorChange::Update(float dt)
{
	UNREFERENCED_PARAMETER(dt);
	if (collided == true)
	{
		sprite->SetColor(collidedColor);
		collided = false;
		timer = collidedColorTime;
	}
	if (collided == false && timer <= 0.f)
	{
		sprite->SetColor(normalColor);
	}
	timer -= dt;
}

void Behaviors::ColorChangeCollisionHandler(GameObject & object, GameObject & other)
{
	UNREFERENCED_PARAMETER(other);
	static_cast<ColorChange*>(object.GetComponent("ColorChange"))->collided = true;
	static_cast<ColorChange*>(object.GetComponent("ColorChange"))->timer = static_cast<ColorChange*>(object.GetComponent("ColorChange"))->collidedColorTime;
}
