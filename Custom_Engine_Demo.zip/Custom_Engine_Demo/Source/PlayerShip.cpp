/*
Name: Tyler Miller
File: PlayerShip.cpp
Date: 10-11-18
Course: CS230
Description: This has all the implementation for functions PlayerShip, Clone, Initialize,
			 Update, Serialize, Deserialize, Move, Rotate, and Shoot
*/

#include "stdafx.h"
#include "PlayerShip.h"
#include "Space.h"
#include "Input.h"
#include "GameObject.h"
#include "Transform.h"
#include "Physics.h"
#include "Parser.h"

Behaviors::PlayerShip::PlayerShip(float forwardThrust, float maximumSpeed, float rotationSpeed, float bulletSpeed)
	: Component("PlayerShip"), forwardThrust(forwardThrust), maximumSpeed(maximumSpeed), rotationSpeed(rotationSpeed), bulletSpeed(bulletSpeed)
{
}

Component* Behaviors::PlayerShip::Clone() const
{
	return new PlayerShip(*this);
}

void Behaviors::PlayerShip::Initialize()
{
	transform = static_cast<Transform*>(GetOwner()->GetComponent("Transform"));
	physics = static_cast<Physics*>(GetOwner()->GetComponent("Physics"));
	bulletArchetype = GetOwner()->GetSpace()->GetObjectManager().GetArchetypeByName("bullet");
}

void Behaviors::PlayerShip::Update(float dt)
{
	UNREFERENCED_PARAMETER(dt);
	PlayerShip::Move();
	PlayerShip::Rotate();
	PlayerShip::Shoot();
}

void Behaviors::PlayerShip::Move() const
{
	float finalRotation = transform->GetRotation();
	float currentVelocity = physics->GetVelocity().Magnitude();
	Vector2D direction = Vector2D::FromAngleRadians(finalRotation);
	if (currentVelocity > maximumSpeed)
	{
		physics->SetVelocity(direction * maximumSpeed);
	}
	if (Input::GetInstance().CheckHeld(VK_UP))
	{
		direction = direction * forwardThrust;
		physics->AddForce(direction);
	}
}

void Behaviors::PlayerShip::Rotate() const
{
	if (Input::GetInstance().CheckHeld(VK_LEFT))
	{
		physics->SetAngularVelocity(rotationSpeed);
	}
	else if (Input::GetInstance().CheckHeld(VK_RIGHT))
	{
		physics->SetAngularVelocity(-rotationSpeed);
	}
	else
	{
		physics->SetAngularVelocity(0);
	}
}

void Behaviors::PlayerShip::Shoot() const
{
	float finalRotation = transform->GetRotation();
	Vector2D direction = Vector2D::FromAngleRadians(finalRotation);
	if (Input::GetInstance().CheckTriggered(VK_SPACE))
	{
		GameObject* bullet = new GameObject(*bulletArchetype);
		direction = direction * bulletSpeed;
		static_cast<Physics*>(bullet->GetComponent("Physics"))->SetVelocity(direction);
		static_cast<Transform*>(bullet->GetComponent("Transform"))->SetTranslation(transform->GetTranslation() + direction / 8);
		static_cast<Transform*>(bullet->GetComponent("Transform"))->SetRotation(transform->GetRotation());
		GetOwner()->GetSpace()->GetObjectManager().AddObject(*bullet);
	}
}
