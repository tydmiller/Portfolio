/*
File: Level2.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Level2.h and implements functions that
Updates the level, initializes the level, loads the level, and unloads the level
*/

#include "stdafx.h"
#include "Level1.h"
#include "Level2.h"
#include "Level3.h"
#include "Platformer.h"
#include "Engine.h"
#include "Space.h"
#include "Mesh.h"
#include "Texture.h"
#include "MeshHelper.h"
#include "SpriteSource.h"
#include "Sprite.h"
#include "Animation.h"
#include "Input.h"
#include "Transform.h"
#include "Physics.h"
#include "Archetypes.h"
#include "GameObjectManager.h"
#include "Tilemap.h"
#include <iostream>

Levels::Level2::Level2()
	: Level("Level2"), columnsMonkey(3), rowsMonkey(5), columnsMap(4), rowsMap(3)
{
}

void Levels::Level2::Load()
{
	std::cout << "Level2::Load" << std::endl;
	meshMonkey = CreateQuadMesh(Vector2D(1.f / static_cast<float>(columnsMonkey), 1.f / static_cast<float>(rowsMonkey)), Vector2D(0.5, 0.5));
	textureMonkey = Texture::CreateTextureFromFile("Monkey.png");
	meshMap = CreateQuadMesh(Vector2D(1.f / static_cast<float>(columnsMap), 1.f / static_cast<float>(rowsMap)), Vector2D(0.5, 0.5));
	dataMap = Tilemap::CreateTilemapFromFile("Level2.txt");
	textureMap = Texture::CreateTextureFromFile("Tilemap.png");
	if (dataMap == nullptr)
	{
		std::cout << "Error loading map!" << std::endl;
	}
	spriteSourceMonkey = new SpriteSource(columnsMonkey, rowsMonkey, textureMonkey);
	spriteSourceMap = new SpriteSource(columnsMap, rowsMap, textureMap);
}

void Levels::Level2::Initialize()
{
	std::cout << "Level2::Initialize" << std::endl;
	GameObject* gameObjectPointer = nullptr;
	GameObject* gameObjectPointerMap = nullptr;
	gameObjectPointer = Archetypes::CreateMonkey(meshMonkey, spriteSourceMonkey);
	gameObjectPointerMap = Archetypes::CreateTilemapObject(meshMap, spriteSourceMap, dataMap);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointer);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerMap);
}

void Levels::Level2::Update(float dt)
{
	UNREFERENCED_PARAMETER(dt);
	if (Input::GetInstance().CheckTriggered('1'))
	{
		GetSpace()->SetLevel(new Level1);
	}
	else if (Input::GetInstance().CheckTriggered('2'))
	{
		GetSpace()->RestartLevel();
	}
	else if (Input::GetInstance().CheckTriggered('3'))
	{
		GetSpace()->SetLevel(new Level3);
	}
	else if (Input::GetInstance().CheckTriggered('4'))
	{
		GetSpace()->SetLevel(new Platformer);
	}
}


void Levels::Level2::Unload()
{
	std::cout << "Level2::Unload" << std::endl;
	delete spriteSourceMonkey;
	delete meshMonkey;
	delete textureMonkey;
	delete dataMap;
	delete meshMap;
	delete textureMap;
	delete spriteSourceMap;
}
