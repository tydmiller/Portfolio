/*
File: Matrix2DStudent.cpp
Name: Tyler Miller
Course: CS230
Date: 11-7-18
Description: This implements the functions from Matrix2DStudent.h and implements functions that
sets the identity matrix, tranposes the matrix, translates the matrix, scales the matrix,
rotates the matrixs in degrees and radians, and multiples matrices together 
*/
#include "stdafx.h"
#include "Matrix2DStudent.h"
namespace CS230
{
	CS230::Matrix2D::Matrix2D()
	{
		memset(m, 0, sizeof(int) * 9);
	}

	Matrix2D CS230::Matrix2D::IdentityMatrix()
	{
		Matrix2D identity;
		identity.m[0][0] = 1;
		identity.m[1][1] = 1;
		identity.m[2][2] = 1;
		return identity;
	}

	Matrix2D CS230::Matrix2D::Transposed() const
	{
		Matrix2D transposeMatrix = *this;
		transposeMatrix.m[0][0] = transposeMatrix.m[0][0];
		transposeMatrix.m[0][1] = transposeMatrix.m[1][0];
		transposeMatrix.m[0][2] = transposeMatrix.m[2][0];
		transposeMatrix.m[1][0] = transposeMatrix.m[0][1];
		transposeMatrix.m[1][1] = transposeMatrix.m[0][2];
		transposeMatrix.m[1][2] = transposeMatrix.m[2][1];
		transposeMatrix.m[2][0] = transposeMatrix.m[0][2];
		transposeMatrix.m[2][1] = transposeMatrix.m[1][2];
		transposeMatrix.m[2][2] = transposeMatrix.m[2][2];
		return transposeMatrix;
	}

	Matrix2D CS230::Matrix2D::TranslationMatrix(float x, float y)
	{
		Matrix2D translateMatrix = IdentityMatrix();
		translateMatrix.m[0][2] = x;
		translateMatrix.m[1][2] = y;
		return translateMatrix;
	}

	Matrix2D CS230::Matrix2D::ScalingMatrix(float x, float y)
	{
		Matrix2D scaleMatrix = IdentityMatrix();
		scaleMatrix.m[0][0] = x;
		scaleMatrix.m[1][1] = y;
		return scaleMatrix;
	}

	Matrix2D CS230::Matrix2D::RotationMatrixDegrees(float angle)
	{
		angle = (angle * static_cast<float>(M_PI)) / 180;
		Matrix2D rotateMatrixDegrees = IdentityMatrix();
		rotateMatrixDegrees.m[0][0] = cos(angle);
		rotateMatrixDegrees.m[0][1] = -sin(angle);
		rotateMatrixDegrees.m[1][0] = sin(angle);
		rotateMatrixDegrees.m[1][1] = cos(angle);
		return rotateMatrixDegrees;
	}

	Matrix2D CS230::Matrix2D::RotationMatrixRadians(float angle)
	{
		Matrix2D rotateMatrixRadians = IdentityMatrix();
		rotateMatrixRadians.m[0][0] = cos(angle);
		rotateMatrixRadians.m[0][1] = -sin(angle);
		rotateMatrixRadians.m[1][0] = sin(angle);
		rotateMatrixRadians.m[1][1] = cos(angle);
		return rotateMatrixRadians;
	}

	Matrix2D CS230::Matrix2D::operator*(const Matrix2D & other) const
	{
		Matrix2D finalMatrix = IdentityMatrix();
		finalMatrix.m[0][0] = RowColumnMultiply(other, 0, 0);
		finalMatrix.m[0][1] = RowColumnMultiply(other, 0, 1);
		finalMatrix.m[0][2] = RowColumnMultiply(other, 0, 2);
		finalMatrix.m[1][0] = RowColumnMultiply(other, 1, 0);
		finalMatrix.m[1][1] = RowColumnMultiply(other, 1, 1);
		finalMatrix.m[1][2] = RowColumnMultiply(other, 1, 2);
		finalMatrix.m[2][0] = RowColumnMultiply(other, 2, 0);
		finalMatrix.m[2][1] = RowColumnMultiply(other, 2, 1);
		finalMatrix.m[2][2] = RowColumnMultiply(other, 2, 2);
		return finalMatrix;
	}

	Matrix2D & CS230::Matrix2D::operator*=(const Matrix2D & other)
	{
		*this = *this * other;
		return *this;
	}

	Vector2D CS230::Matrix2D::operator*(const Vector2D & vec) const
	{
		Vector2D finalVector;
		finalVector.x = (m[0][0] * vec.x + m[0][1] * vec.y + m[0][2]);
		finalVector.y = (m[1][0] * vec.x + m[1][1] * vec.y + m[1][2]);
		return finalVector;
	}

	float CS230::Matrix2D::RowColumnMultiply(const Matrix2D & other, unsigned row, unsigned col) const
	{
		float finalNum;
		finalNum = m[row][0] * other.m[0][col] + m[row][1] * other.m[1][col] + m[row][2] * other.m[2][col];
		return finalNum;
	}
}
