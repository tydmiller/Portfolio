//------------------------------------------------------------------------------
//
// File Name:	Platformer.h
// Author(s):	Jeremy Kings (j.kings)
// Project:		BetaFramework
// Course:		WANIC VGP2 2018-2019
//
// Copyright � 2018 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#pragma once

//------------------------------------------------------------------------------
// Include Files:
//------------------------------------------------------------------------------

#include "Vector2D.h"
#include "Level.h"

//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Forward References:
//------------------------------------------------------------------------------

class Texture;
class Mesh;
class SpriteSource;
class GameObject;
class Tilemap;

//------------------------------------------------------------------------------
// Public Structures:
//------------------------------------------------------------------------------

namespace Levels
{
	class Platformer : public Level
	{
	public:
		//------------------------------------------------------------------------------
		// Public Functions:
		//------------------------------------------------------------------------------

		// Creates an instance of Platformer.
		Platformer();

		// Load the resources associated with Platformer.
		void Load() override;

		// Initialize the memory associated with Platformer.
		void Initialize() override;

		// Update Platformer.
		// Params:
		//	 dt = Change in time (in seconds) since the last game loop.
		void Update(float dt) override;

		// Unload the resources associated with Platformer.
		void Unload() override;

	private:

		//------------------------------------------------------------------------------
		// Private Variables:
		//------------------------------------------------------------------------------
		Mesh* meshCollectible; //mesh for collectible
		Texture* textureCollectible; //texture for collectible
		SpriteSource* spriteSourceCollectible; //sprite for collectible

		Mesh* meshMonkey; //mesh for monkey
		Texture* textureMonkey; //textuer for monkey
		SpriteSource* spriteSourceMonkey; //sprite source for monkey
		int rowsMonkey; //rows for monkey image
		int columnsMonkey; //columns for monkey image

		Tilemap* dataMap; //data for the tilemap
		Texture* textureMap; //texture for the tilemap
		SpriteSource* spriteSourceMap; //sprite source for the tilemap
		Mesh* meshMap; //mesh for the tilemap

		unsigned columnsMap; //columns for tilemap
		unsigned rowsMap; //rows for tilemap

		Mesh* meshEnemy; //mesh for enemy
	};
}

//----------------------------------------------------------------------------
