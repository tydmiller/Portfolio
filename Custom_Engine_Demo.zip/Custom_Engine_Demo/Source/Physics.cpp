/*
File: Physics.cpp
Name: Tyler Miller
Course: CS230
Date: 11-7-18
Description: This implements the functions from Physics.h and implements functions that
update physics, fix update physics, sets velocity, gets velocity, sets angular velocity,
gets angular velocity, sets mass, add force, gets the acceleration, and gets the old
translation
*/
#include "stdafx.h"
#include "Physics.h"
#include "Transform.h"
#include "Space.h"

Physics::Physics()
	: Component("Physics"), transform(nullptr), angularVelocity(0), inverseMass(1.f)
{
}

Component * Physics::Clone() const
{
	return new Physics(*this);
}

void Physics::Initialize()
{
	transform = static_cast<Transform *>(GetOwner()->GetComponent("Transform"));
}

void Physics::Update(float dt)
{
	UNREFERENCED_PARAMETER(dt);
	acceleration = forcesSum * inverseMass;
	forcesSum = Vector2D(0, 0);
}

void Physics::FixedUpdate(float dt)
{
	velocity = velocity + acceleration * dt;
	oldTranslation = transform->GetTranslation();
	Vector2D newTranslation = oldTranslation + velocity * dt;
	float newRotation = transform->GetRotation() + angularVelocity * dt;
	transform->SetTranslation(newTranslation);
	transform->SetRotation(newRotation);
}

void Physics::SetVelocity(const Vector2D & velocitys)
{
	velocity = velocitys;
}

const Vector2D & Physics::GetVelocity() const
{
	return velocity;
}

void Physics::SetAngularVelocity(float velocitys)
{
	angularVelocity = velocitys;
}

float Physics::GetAngularVelocity() const
{
	return angularVelocity;
}

void Physics::SetMass(float masses)
{
	inverseMass = 1 / masses;
}

void Physics::AddForce(const Vector2D & forces)
{
	forcesSum += forces;
}

const Vector2D & Physics::GetAcceleration() const
{
	return acceleration;
}

const Vector2D & Physics::GetOldTranslation() const
{
	return oldTranslation;
}
