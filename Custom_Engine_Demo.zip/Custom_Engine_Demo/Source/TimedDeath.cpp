/*
Name: Tyler Miller
File: TimedDeath.cpp
Date: 10-11-18
Course: CS230
Description: This has all the implementation for functions TimedDeath, ~TimedDeath,
			 Clone, Update, Serialize, Deserialize, GetInstanceCount
*/
#include "stdafx.h"
#include "TimedDeath.h"
#include "GameObject.h"
#include "Space.h"
#include "GameObjectManager.h"
#include "Parser.h"

Behaviors::TimedDeath::TimedDeath(float timeUntilDeath)
	: Component("TimedDeath"), timeUntilDeath(timeUntilDeath)
{
}

Component * Behaviors::TimedDeath::Clone() const
{
	return new TimedDeath(*this);
}

void Behaviors::TimedDeath::Update(float dt)
{
	timeUntilDeath -= dt;
	if (timeUntilDeath <= 0)
	{
		GetOwner()->Destroy();
	}
}

