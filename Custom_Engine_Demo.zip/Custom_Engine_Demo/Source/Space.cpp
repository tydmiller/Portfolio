/*
File: Space.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Space.h and implements functions that
Updates the space and changes the level, Shuts down the space, and restarts
the level.
*/
#include "stdafx.h"
#include "Space.h"
#include "Level.h"
#include <iostream>

Space::Space(const std::string & name)
	:BetaObject(name), paused(false), currentLevel(nullptr), nextLevel(nullptr), objectManager(this)
{
}

Space::~Space()
{
	Shutdown();
}

void Space::Update(float dt)
{
	if (nextLevel != nullptr)
	{
		ChangeLevel();
	}
	if (currentLevel != nullptr && paused == false)
	{
		objectManager.Update(dt);
		currentLevel->Update(dt);
	}
}

void Space::Shutdown()
{
	if (currentLevel != nullptr)
	{
		objectManager.Shutdown();
		objectManager.Unload();
		currentLevel->Shutdown();
		currentLevel->Unload();
		delete currentLevel;
		currentLevel = nullptr;
	}
}

bool Space::IsPaused() const
{
	return paused;
}

const std::string & Space::GetLevelName() const
{
	return currentLevel->GetName();
}

void Space::SetPaused(bool value)
{
	paused = value;
}

void Space::SetLevel(Level* level)
{
	nextLevel = level;
	nextLevel->SetParent(this);
}

void Space::RestartLevel()
{
	nextLevel = currentLevel;
}

GameObjectManager & Space::GetObjectManager()
{
	return objectManager;
}

void Space::ChangeLevel()
{
	if (nextLevel == currentLevel)
	{
		objectManager.Shutdown();
		currentLevel->Shutdown();
		nextLevel->Initialize();
	}
	if (nextLevel != currentLevel)
	{
		//this is to make sure that the current level exist
		if (currentLevel != nullptr)
		{
			objectManager.Shutdown();
			objectManager.Unload();
			currentLevel->Shutdown();
			currentLevel->Unload();
		}
		nextLevel->Load();
		nextLevel->Initialize();
		//make sure to delete memory so the memory is not lost
		delete currentLevel;
	}
	currentLevel = nextLevel;
	nextLevel = nullptr;
}
