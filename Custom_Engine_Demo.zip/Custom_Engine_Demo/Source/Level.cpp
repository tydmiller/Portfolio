/*
File: Level.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Level.h and implements functions that
gets the space
*/

#include "stdafx.h"
#include "Level.h"
#include "Engine.h"
#include "Space.h"

Level::Level(const std::string & name)
	:BetaObject(name)
{
}

Space * Level::GetSpace() const
{
	return static_cast<Space*>(GetParent());
}
