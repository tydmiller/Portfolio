/*
File: Tilemap.cpp
Name: Tyler Miller
Course: CS230
Date: 11-7-18
Description: This implements the functions from Tilemap.h and implements functions that
calls the destructor, gets width, gets height, gets cell value, creates tilemap from 
file, read integer variable, reads array variable
*/
#include "stdafx.h"
#include "Tilemap.h"
#include <fstream>
#include <iostream>

Tilemap::Tilemap(unsigned numColumns, unsigned numRows, int ** data)
	: numColumns(numColumns), numRows(numRows), data(data)
{
}

Tilemap::~Tilemap()
{
	for (unsigned int c = 0; c < numColumns; ++c)
	{
		delete[] data[c];
		data[c] = nullptr;
	}
	delete[] data;
	data = nullptr;
}

unsigned Tilemap::GetWidth() const
{
	return numColumns;
}

unsigned Tilemap::GetHeight() const
{
	return numRows;
}

int Tilemap::GetCellValue(unsigned column, unsigned row) const
{
	if (column >= numColumns || row >= numRows)
	{
		return -1;
	}
	return data[column][row];
}

Tilemap * Tilemap::CreateTilemapFromFile(const std::string & filename)
{
	std::ifstream infile("assets/levels/" + filename);
	if (infile.is_open() == false)
	{
		std::cout << "Can't open file." << std::endl;
	}
	else
	{
		int width = 0;
		int height = 0;
		if (ReadIntegerVariable(infile, "width", width) == true && ReadIntegerVariable(infile, "height", height) == true)
		{
			int **tileArray = ReadArrayVariable(infile, "data", width, height);
			return new Tilemap(width, height, tileArray);
		}
	}
	return nullptr;
}

bool Tilemap::ReadIntegerVariable(std::ifstream & file, const std::string & name, int & variable)
{
	std::string text;
	if (file.is_open() == true)
	{
		file >> text;
		if (text == name)
		{
			file >> variable;
			return true;
		}
	}
	return false;
}

int ** Tilemap::ReadArrayVariable(std::ifstream & file, const std::string & name, unsigned columns, unsigned rows)
{
	std::string text;
	int **theArray;
	if(file.is_open() == true)
	{
		file >> text;
		if (text != name || columns <= 0 || rows <= 0)
		{
			return nullptr;
		}
		theArray = new int *[columns];
		for (unsigned int i = 0; i < columns; ++i)
		{
			theArray[i] = new int[rows];
		}
		for (unsigned int r = 0; r < rows; ++r)
		{
			for (unsigned int c = 0; c < columns; ++c)
			{
				int currNum = 0;
				file >> currNum;
				theArray[c][r] = currNum;
			}
		}
		return theArray;
	}
	return nullptr;
}
