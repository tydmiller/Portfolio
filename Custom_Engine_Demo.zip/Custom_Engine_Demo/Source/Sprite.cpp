/*
File: Sprite.cpp
Name: Tyler Miller
Course: CS230
Date: 10-31-18
Description: This implements the functions from Sprite.h and implements functions that
plays the animation, updates the animation, and returns if the animation is done
*/
#include "stdafx.h"
#include "Sprite.h"
#include "SpriteSource.h"
#include "Vector2D.h"
#include "Graphics.h"
#include "Mesh.h"
#include "Transform.h"
#include "Space.h"
#include <iostream>

Sprite::Sprite()
	: Component("Sprite"),frameIndex(0), spriteSource(nullptr), mesh(nullptr), transform(nullptr)
{
}

Component * Sprite::Clone() const
{
	return new Sprite(*this);
}

void Sprite::Initialize()
{
	transform = static_cast<Transform *>(GetOwner()->GetComponent("Transform"));
}

void Sprite::Draw()
{
	Draw(Vector2D(0, 0));
}

void Sprite::Draw(const Vector2D & offset)
{
	Graphics& graphics = Graphics::GetInstance();
	Vector2D startVector = Vector2D(0, 0);
	if (transform == nullptr)
	{
		return;
	}
	if (mesh == nullptr)
	{
		return;
	}
	if (spriteSource != nullptr)
	{
		spriteSource->GetUV(frameIndex, startVector);
		graphics.SetTexture(spriteSource->GetTexture(), startVector);
	}
	else
	{
		graphics.SetTexture(nullptr, startVector);
	}
	graphics.SetSpriteBlendColor(color);
	CS230::Matrix2D transformMatrix = CS230::Matrix2D::TranslationMatrix(offset.x, offset.y);
	transformMatrix = transformMatrix * transform->GetMatrix();
	graphics.SetTransform(reinterpret_cast<const Matrix2D&>(transformMatrix));
	mesh->Draw();
}

void Sprite::SetAlpha(float alpha)
{
	color.a = alpha;
}

float Sprite::GetAlpha() const
{
	return color.a;
}

void Sprite::SetFrame(unsigned int frameIndexs)
{
	if (spriteSource == nullptr)
	{
		return;
	}
	if (spriteSource->GetFrameCount() > frameIndexs)
	{
		frameIndex = frameIndexs;
	}
}

unsigned Sprite::GetFrame() const
{
	return frameIndex;
}

void Sprite::SetMesh(Mesh * meshs)
{
	mesh = meshs;
}

void Sprite::SetSpriteSource(SpriteSource * spriteSources)
{
	spriteSource = spriteSources;
}

void Sprite::SetColor(Color colors)
{
	color = colors;
}

const Color & Sprite::GetColor() const
{
	// TODO: insert return statement here
	return color;
}
