/*
File: Collider.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Collider.h and implements functions that
initializes the collider class, checks collision, gets the type of the collision, sets
the collision handler, gets map collision handler
*/

#include "stdafx.h"
#include "Collider.h"
#include "Space.h"
#include "Transform.h"
#include "Physics.h"

Collider::Collider(ColliderType type)
	:Component("Collider"), type(type), handler(nullptr), mapHandler(nullptr)
{
}

void Collider::Initialize()
{
	transform = static_cast<Transform*>(GetOwner()->GetComponent("Transform"));
	physics = static_cast<Physics*>(GetOwner()->GetComponent("Physics"));
}

void Collider::CheckCollision(const Collider & other)
{
	if (IsCollidingWith(other) == true)
	{
		if (handler != nullptr)
		{
			handler(*GetOwner(), *other.GetOwner());
		}
		if (other.handler != nullptr)
		{
			other.handler(*other.GetOwner(), *GetOwner());
		}
	}
}

ColliderType Collider::GetType() const
{
	return type;
}

void Collider::SetCollisionHandler(CollisionEventHandler handlers)
{
	handler = handlers;
}

void Collider::SetMapCollisionHandler(MapCollisionEventHandler mapHandlers)
{
	mapHandler = mapHandlers;
}

MapCollisionEventHandler Collider::GetMapCollisionHandler() const
{
	return mapHandler;
}

MapCollision::MapCollision(bool bottom, bool top, bool left, bool right)
	: bottom(bottom), top(top), left(left), right(right)
{
}
