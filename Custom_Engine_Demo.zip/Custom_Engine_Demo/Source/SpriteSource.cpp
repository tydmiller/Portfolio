/*
File: SpriteSource.cpp
Name: Tyler Miller
Course: CS230
Date: 10-31-18
Description: This implements the functions from SpriteSource.h and implements functions that
returns the texture, returns the frame count, and gets the UV coordinates
*/
#include "stdafx.h"
#include "SpriteSource.h"
#include "Vector2D.h"

SpriteSource::SpriteSource(int numCols, int numRows, Texture * texture)
	: numCols(numCols), numRows(numRows), texture(texture)
{
}

Texture * SpriteSource::GetTexture() const
{
	return texture;
}

unsigned SpriteSource::GetFrameCount() const
{
	return numCols * numRows;
}

void SpriteSource::GetUV(unsigned int frameIndex, Vector2D & textureCoords) const
{
	float uSize = 1.f / static_cast<float>(numCols);
	float vSize = 1.f / static_cast<float>(numRows);
	int y = frameIndex / numCols;
	int x = frameIndex % numCols;
	float u = uSize * x;
	float v = vSize * y;
	textureCoords = Vector2D(u, v);
}
