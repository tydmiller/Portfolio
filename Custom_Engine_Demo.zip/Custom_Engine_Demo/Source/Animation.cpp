/*
File: Animation.cpp
Name: Tyler Miller
Course: CS230
Date: 10-31-18
Description: This implements the functions from Animation.h and implements functions that
plays the animation, updates the animation, and returns if the animation is done
*/
#include "stdafx.h"
#include "Animation.h"
#include "Sprite.h"
#include "Space.h"
#include <iostream>

Animation::Animation()
	: Component("Animation"), sprite(nullptr)
{
}

Component * Animation::Clone() const
{
	return new Animation(*this);
}

void Animation::Initialize()
{
	sprite = static_cast<Sprite*>(GetOwner()->GetComponent("Sprite"));
}

void Animation::Play(unsigned frameStarts, unsigned frameCounts, float frameDurations, bool isLoopings)
{
	frameStart = frameStarts;
	frameCount = frameCounts;
	frameDuration = frameDurations;
	isLooping = isLoopings;
	frameDelay = frameDuration;
	frameIndex = frameStart;
	sprite->SetFrame(frameIndex);
	isRunning = true;
	isDone = false;
}

void Animation::Update(float dt)
{
	if (isRunning == false)
	{
		return;
	}
	frameDelay -= dt;
	if (frameDelay <= 0)
	{
		frameDelay = frameDuration;
		if (frameIndex == frameCount && isDone == false)
		{
			if (isLooping == false)
			{
				isRunning = false;
			}
			if (isLooping == true)
			{
				frameIndex = frameStart;
			}
			isDone = true;
			sprite->SetFrame(frameIndex);

		}
		else
		{
			frameIndex += 1;
			isDone = false;
			sprite->SetFrame(frameIndex);
		}
	}
}

bool Animation::IsDone() const
{
	return isDone;
}
