/*
File: ColliderTilemap.cpp
Name: Tyler Miller
Course: CS230
Date: 11-7-18
Description: This implements the functions from ColliderTilemap.h and implements functions that
clone, is colliding with other objects, set tile map, is side colliding with, is collision
at given position, resolves collisions, get next tile center
*/
#include "stdafx.h"
#include "ColliderTilemap.h"
#include "ColliderRectangle.h"
#include "Intersection2D.h"
#include "Space.h"
#include "Transform.h"
#include "Physics.h"
#include "Matrix2DStudent.h"
#include "Tilemap.h"

ColliderTilemap::ColliderTilemap()
	: Collider(ColliderTypeTilemap), map(nullptr)
{
}

Component * ColliderTilemap::Clone() const
{
	return new ColliderTilemap(*this);
}

void ColliderTilemap::Draw()
{
}

bool ColliderTilemap::IsCollidingWith(const Collider & other) const
{
	if (other.GetType() == ColliderTypeRectangle)
	{
		const ColliderRectangle& otherRectangleCollider = static_cast<const ColliderRectangle&>(other);
		BoundingRectangle otherRectangle = BoundingRectangle(static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation(), otherRectangleCollider.GetExtents());
		MapCollision tileMapCollision = MapCollision(false, false, false, false);
		Transform* otherTransform = static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"));
		Physics* otherPhysics = static_cast<Physics*>(other.GetOwner()->GetComponent("Physics"));
		Vector2D otherTranslation = static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation();
		Vector2D otherVelocity = static_cast<Physics*>(other.GetOwner()->GetComponent("Physics"))->GetVelocity();
		tileMapCollision.left = IsSideColliding(otherRectangle, SideLeft);
		tileMapCollision.right = IsSideColliding(otherRectangle, SideRight);
		tileMapCollision.top = IsSideColliding(otherRectangle, SideTop);
		tileMapCollision.bottom = IsSideColliding(otherRectangle, SideBottom);
		static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->SetTranslation(otherTranslation);
		static_cast<Physics*>(other.GetOwner()->GetComponent("Physics"))->SetVelocity(otherVelocity);
		if (tileMapCollision.top == true || tileMapCollision.bottom == true || tileMapCollision.right == true || tileMapCollision.left == true)
		{
			ResolveCollisions(otherRectangle, otherTransform, otherPhysics, tileMapCollision);
			if (other.GetMapCollisionHandler() != nullptr)
			{
				other.GetMapCollisionHandler()(*other.GetOwner(), tileMapCollision);
				return true;
			}
		}
	}
	return false;
}

void ColliderTilemap::SetTilemap(const Tilemap * maps)
{
	map = maps;
}

bool ColliderTilemap::IsSideColliding(const BoundingRectangle & rectangle, RectangleSide side) const
{
	if (side == SideBottom)
	{
		Vector2D bottomHotSpot = Vector2D(rectangle.center.x + -rectangle.extents.x / 2, rectangle.bottom);
		Vector2D bottomHotSpotTwo = Vector2D(rectangle.center.x + rectangle.extents.x / 2, rectangle.bottom);
		if (IsCollidingAtPosition(bottomHotSpot.x, bottomHotSpot.y) == true || IsCollidingAtPosition(bottomHotSpotTwo.x, bottomHotSpotTwo.y) == true)
		{
			return true;
		}
	}
	if (side == SideTop)
	{
		Vector2D topHotSpot = Vector2D(rectangle.center.x + -rectangle.extents.x / 2, rectangle.top);
		Vector2D topHotSpotTwo = Vector2D(rectangle.center.x + rectangle.extents.x / 2, rectangle.top);
		if (IsCollidingAtPosition(topHotSpot.x, topHotSpot.y) == true || IsCollidingAtPosition(topHotSpotTwo.x, topHotSpotTwo.y) == true)
		{
			return true;
		}
	}
	if (side == SideRight)
	{
		Vector2D rightHotSpot = Vector2D(rectangle.right, rectangle.center.y + rectangle.extents.y / 2);
		Vector2D rightHotSpotTwo = Vector2D(rectangle.right, rectangle.center.y + -rectangle.extents.y / 2);
		if (IsCollidingAtPosition(rightHotSpot.x, rightHotSpot.y) == true || IsCollidingAtPosition(rightHotSpotTwo.x, rightHotSpotTwo.y) == true)
		{
			return true;
		}
	}
	if (side == SideLeft)
	{
		Vector2D leftHotSpot = Vector2D(rectangle.left, rectangle.center.y + rectangle.extents.y / 2);
		Vector2D leftHotSpotTwo = Vector2D(rectangle.left, rectangle.center.y + -rectangle.extents.y / 2);
		if (IsCollidingAtPosition(leftHotSpot.x, leftHotSpot.y) == true || IsCollidingAtPosition(leftHotSpotTwo.x, leftHotSpotTwo.y) == true)
		{
			return true;
		}
	}
	return false;
}

bool ColliderTilemap::IsCollidingAtPosition(float x, float y) const
{
	Vector2D givenPoint = Vector2D(x, y);
	Vector2D tileVector = transform->GetInverseMatrix() * givenPoint;
	if (map->GetCellValue(static_cast<int>(tileVector.x + 0.5f), static_cast<int>(-tileVector.y + 0.5f)) != 0)
	{
		return true;
	}
	return false;
}

void ColliderTilemap::ResolveCollisions(const BoundingRectangle & objectRectangle, Transform * objectTransform, Physics * objectPhysics, const MapCollision & collisions) const
{
	Vector2D translation = objectTransform->GetTranslation();
	Vector2D velocity = objectPhysics->GetVelocity();
	float nudgeAmount;
	float nextTileCenter;
	
	if (collisions.bottom == true || collisions.top == true)
	{
		if (collisions.bottom == true)
		{
			nextTileCenter = GetNextTileCenter(SideBottom, objectRectangle.bottom);
			nudgeAmount = nextTileCenter - objectRectangle.bottom;
		}
		else
		{
			nextTileCenter = GetNextTileCenter(SideTop, objectRectangle.top);
			nudgeAmount = nextTileCenter - objectRectangle.top;
		}
		translation.y += nudgeAmount;
		velocity.y = 0;
	}
	if (collisions.right == true || collisions.left == true)
	{
		if (collisions.left == true)
		{
			nextTileCenter = GetNextTileCenter(SideLeft, objectRectangle.left);
			nudgeAmount = nextTileCenter - objectRectangle.left;
		}
		else
		{
			nextTileCenter = GetNextTileCenter(SideRight, objectRectangle.right);
			nudgeAmount = nextTileCenter - objectRectangle.right;
		}
		translation.x += nudgeAmount;
		velocity.x = 0;
	}
	objectTransform->SetTranslation(translation);
	objectPhysics->SetVelocity(velocity);
}

float ColliderTilemap::GetNextTileCenter(RectangleSide side, float sidePosition) const
{
	Vector2D point;
	float* result;
	if (side == SideTop || side == SideBottom)
	{
		point = Vector2D(0, sidePosition);
		result = &point.y;
	}
	else
	{
		point = Vector2D(sidePosition, 0);
		result = &point.x;
	}
	point = transform->GetInverseMatrix() * point;
	point.y = -point.y;
	point += Vector2D(0.5, 0.5);
	if (side == SideLeft || side == SideTop)
	{
		*result = ceil(*result);
	}
	else
	{
		*result = floor(*result);
	}
	point -= Vector2D(0.5, 0.5);
	point.y = -point.y;
	point = transform->GetMatrix() * point;
	return *result;
}
