/*
File: Platformer.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Platformer.h and implements functions that
Updates the level, initializes the level, loads the level, and unloads the level
*/
#include "stdafx.h"
#include "Platformer.h"
#include "Level1.h"
#include "Level2.h"
#include "Level3.h"
#include "Engine.h"
#include "Space.h"
#include "Mesh.h"
#include "Texture.h"
#include "MeshHelper.h"
#include "SpriteSource.h"
#include "Sprite.h"
#include "Animation.h"
#include "Input.h"
#include "Transform.h"
#include "Physics.h"
#include "Archetypes.h"
#include "GameObjectManager.h"
#include "Tilemap.h"
#include "Collider.h"
#include "ColliderRectangle.h"
#include "ColliderCircle.h"
#include <iostream>

Levels::Platformer::Platformer()
	: Level("Platformer"), columnsMonkey(3), rowsMonkey(5), columnsMap(4), rowsMap(3), dataMap(nullptr)
{
}

void Levels::Platformer::Load()
{
	std::cout << "Platformer::Load" << std::endl;
	meshMonkey = CreateQuadMesh(Vector2D(1.f / static_cast<float>(columnsMonkey), 1.f / static_cast<float>(rowsMonkey)), Vector2D(0.5, 0.5));
	textureMonkey = Texture::CreateTextureFromFile("Monkey.png");
	spriteSourceMonkey = new SpriteSource(columnsMonkey, rowsMonkey, textureMonkey);
	meshMap = CreateQuadMesh(Vector2D(1.f / static_cast<float>(columnsMap), 1.f / static_cast<float>(rowsMap)), Vector2D(0.5, 0.5));
	dataMap = Tilemap::CreateTilemapFromFile("Platformer.txt");
	textureMap = Texture::CreateTextureFromFile("Tilemap.png");
	if (dataMap == nullptr)
	{
		std::cout << "Error loading map!" << std::endl;
	}
	meshCollectible = CreateQuadMesh(Vector2D(1, 1), Vector2D(0.5, 0.5));
	meshEnemy = CreateQuadMesh(Vector2D(1, 1), Vector2D(0.5, 0.5));
	textureCollectible = Texture::CreateTextureFromFile("Circle.png");
	spriteSourceCollectible = new SpriteSource(1, 1, textureCollectible);
	spriteSourceMap = new SpriteSource(columnsMap, rowsMap, textureMap);
	GameObject* gameObjectCollectible = Archetypes::CreateCollectibleObject(meshCollectible, spriteSourceCollectible);
	GetSpace()->GetObjectManager().AddArchetype(*gameObjectCollectible);
}

void Levels::Platformer::Initialize()
{
	GameObject* copyOfCollectible = new GameObject(*GetSpace()->GetObjectManager().GetArchetypeByName("collectible"));
	GameObject* copyOfCollectibleTwo = new GameObject(*GetSpace()->GetObjectManager().GetArchetypeByName("collectible"));
	GameObject* copyOfCollectibleThree = new GameObject(*GetSpace()->GetObjectManager().GetArchetypeByName("collectible"));
	GameObject* copyOfCollectibleFour = new GameObject(*GetSpace()->GetObjectManager().GetArchetypeByName("collectible"));
	GameObject* gameObjectPointerPlayer = Archetypes::CreateMonkey(meshMonkey, spriteSourceMonkey);
	GameObject* gameObjectPointerEnemy = Archetypes::CreateEnemy(meshEnemy);
	GameObject* gameObjectPointerEnemyTwo = Archetypes::CreateEnemy(meshEnemy);
	GameObject* gameObjectPointerHazard = Archetypes::CreateHazard(meshEnemy);
	GameObject* gameObjectPointerHazardTwo = Archetypes::CreateHazard(meshEnemy);
	GameObject* gameObjectPointerMap = Archetypes::CreateTilemapObject(meshMap, spriteSourceMap, dataMap);
	static_cast<Transform*>(gameObjectPointerMap->GetComponent("Transform"))->SetScale(Vector2D(50, 50));
	static_cast<Transform*>(gameObjectPointerPlayer->GetComponent("Transform"))->SetScale(Vector2D(50, 50));
	static_cast<ColliderRectangle*>(gameObjectPointerPlayer->GetComponent("Collider"))->SetExtents(static_cast<Transform*>(gameObjectPointerPlayer->GetComponent("Transform"))->GetScale() / 2);
	static_cast<ColliderRectangle*>(gameObjectPointerEnemy->GetComponent("Collider"))->SetExtents(static_cast<Transform*>(gameObjectPointerEnemy->GetComponent("Transform"))->GetScale() / 2);
	static_cast<ColliderRectangle*>(gameObjectPointerEnemyTwo->GetComponent("Collider"))->SetExtents(static_cast<Transform*>(gameObjectPointerEnemyTwo->GetComponent("Transform"))->GetScale() / 2);
	static_cast<ColliderRectangle*>(gameObjectPointerHazardTwo->GetComponent("Collider"))->SetExtents(static_cast<Transform*>(gameObjectPointerHazard->GetComponent("Transform"))->GetScale() / 2);
	static_cast<ColliderRectangle*>(gameObjectPointerHazard->GetComponent("Collider"))->SetExtents(static_cast<Transform*>(gameObjectPointerHazardTwo->GetComponent("Transform"))->GetScale() / 2);
	static_cast<ColliderCircle*>(copyOfCollectible->GetComponent("Collider"))->SetRadius(static_cast<ColliderCircle*>(copyOfCollectible->GetComponent("Collider"))->GetRadius() / 2);
	static_cast<ColliderCircle*>(copyOfCollectibleTwo->GetComponent("Collider"))->SetRadius(static_cast<ColliderCircle*>(copyOfCollectibleTwo->GetComponent("Collider"))->GetRadius() / 2);
	static_cast<ColliderCircle*>(copyOfCollectibleThree->GetComponent("Collider"))->SetRadius(static_cast<ColliderCircle*>(copyOfCollectibleThree->GetComponent("Collider"))->GetRadius() / 2);
	static_cast<ColliderCircle*>(copyOfCollectibleFour->GetComponent("Collider"))->SetRadius(static_cast<ColliderCircle*>(copyOfCollectibleFour->GetComponent("Collider"))->GetRadius() / 2);
	static_cast<Transform*>(gameObjectPointerEnemyTwo->GetComponent("Transform"))->SetTranslation(Vector2D(150, -200));
	static_cast<Transform*>(gameObjectPointerHazard->GetComponent("Transform"))->SetTranslation(Vector2D(300, 20));
	static_cast<Transform*>(gameObjectPointerHazardTwo->GetComponent("Transform"))->SetTranslation(Vector2D(-300, 20));
	static_cast<Transform*>(copyOfCollectible->GetComponent("Transform"))->SetTranslation(Vector2D(200, 150));
	static_cast<Transform*>(copyOfCollectibleTwo->GetComponent("Transform"))->SetTranslation(Vector2D(-100, 150));
	static_cast<Transform*>(copyOfCollectibleThree->GetComponent("Transform"))->SetTranslation(Vector2D(-200, -150));
	static_cast<Transform*>(copyOfCollectibleFour->GetComponent("Transform"))->SetTranslation(Vector2D(200, -150));
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerEnemy);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerEnemyTwo);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerHazard);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerHazardTwo);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerMap);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerPlayer);
	GetSpace()->GetObjectManager().AddObject(*copyOfCollectible);
	GetSpace()->GetObjectManager().AddObject(*copyOfCollectibleTwo);
	GetSpace()->GetObjectManager().AddObject(*copyOfCollectibleThree);
	GetSpace()->GetObjectManager().AddObject(*copyOfCollectibleFour);
}

void Levels::Platformer::Update(float dt)
{
	UNREFERENCED_PARAMETER(dt);
	if (GetSpace()->GetObjectManager().GetObjectCount("collectible") <= 0)
	{
		Engine::GetInstance().Stop();
	}
	if (Input::GetInstance().CheckTriggered('1'))
	{
		GetSpace()->SetLevel(new Level1);
	}
	else if (Input::GetInstance().CheckTriggered('2'))
	{
		GetSpace()->SetLevel(new Level2);
	}
	else if (Input::GetInstance().CheckTriggered('3'))
	{
		GetSpace()->SetLevel(new Level3);
	}
	else if (Input::GetInstance().CheckTriggered('4'))
	{
		GetSpace()->RestartLevel();
	}
}

void Levels::Platformer::Unload()
{
	delete meshMonkey;
	delete textureMonkey;
	delete spriteSourceMonkey;
	delete meshCollectible;
	delete textureCollectible;
	delete spriteSourceCollectible;
	delete meshMap;
	delete dataMap;
	delete textureMap;
	delete spriteSourceMap;
	delete meshEnemy;
}
