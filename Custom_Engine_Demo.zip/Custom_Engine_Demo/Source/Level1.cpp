/*
File: Level1.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Level1.h and implements functions that
Updates the level, initializes the level, loads the level, and unloads the level
*/
#include "stdafx.h"
#include "Level1.h"
#include "Level2.h"
#include "Level3.h"
#include "Platformer.h"
#include "Engine.h"
#include "Space.h"
#include "MeshHelper.h"
#include "Color.h"
#include "Sprite.h"
#include "Mesh.h"
#include "Input.h"
#include "Transform.h"
#include "Physics.h"
#include "Archetypes.h"
#include "GameObjectManager.h"
#include <iostream>

Levels::Level1::Level1()
	: Level("Level1"), meshShip(nullptr), meshBullet(nullptr)
{
}

void Levels::Level1::Load()
{
	std::cout << "Level1::Load" << std::endl;
	meshShip = CreateTriangleMesh(Colors::Red, Colors::Blue, Colors::Green);
	meshBullet = CreateTriangleMesh(Colors::Blue, Colors::Blue, Colors::Blue);
	GameObject* gameObjectPointerBullet = Archetypes::CreateBulletArchetype(meshBullet);
	GetSpace()->GetObjectManager().AddArchetype(*gameObjectPointerBullet);
}

void Levels::Level1::Initialize()
{
	std::cout << "Level1::Initialize" << std::endl;
	GameObject* gameObjectPointerShip = nullptr;
	gameObjectPointerShip = Archetypes::CreateShip(meshShip);
	GetSpace()->GetObjectManager().AddObject(*gameObjectPointerShip);
}

void Levels::Level1::Update(float dt)
{
	UNREFERENCED_PARAMETER(dt);
	if (Input::GetInstance().CheckTriggered('1'))
	{
		GetSpace()->RestartLevel();
	}
	else if (Input::GetInstance().CheckTriggered('2'))
	{
		GetSpace()->SetLevel(new Level2);
	}
	else if (Input::GetInstance().CheckTriggered('3'))
	{
		GetSpace()->SetLevel(new Level3);
	}
	else if (Input::GetInstance().CheckTriggered('4'))
	{
		GetSpace()->SetLevel(new Platformer);
	}
}

void Levels::Level1::Unload()
{
	std::cout << "Level1::Unload" << std::endl;
	delete meshShip;
	delete meshBullet;
}