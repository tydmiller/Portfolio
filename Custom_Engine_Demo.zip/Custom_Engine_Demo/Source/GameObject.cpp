/*
File: GameObject.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from GameObject.h and implements functions that
initialize the game object, updates the game object, fixed updates the game object,
draws the game object, add the component to the game object, destroy the component, 
gets the is destroyed variable, and gets space
*/
#include "stdafx.h"
#include "GameObject.h"
#include "Component.h"
#include "Space.h"

GameObject::GameObject(const std::string & name)
	: BetaObject(name), numComponents(0), isDestroyed(false)
{
}

GameObject::GameObject(const GameObject & other)
	: BetaObject(other.GetName()), numComponents(0), isDestroyed(false)
{
	for (unsigned int i = 0; i < other.numComponents; i++)
	{
		AddComponent(other.components[i]->Clone());
	}
}

GameObject::~GameObject()
{
	for (unsigned int i = 0; i < numComponents; i++)
	{
		delete components[i];
	}
}

void GameObject::Initialize()
{
	for (unsigned int i = 0; i < numComponents; i++)
	{
		if (components[i] != nullptr)
		{
			components[i]->Initialize();
		}
	}
}

void GameObject::Update(float dt)
{
	if (isDestroyed == true)
	{
		return;
	}
	for (unsigned int i = 0; i < numComponents; i++)
	{
		if (components[i] != nullptr)
		{
			components[i]->Update(dt);
		}
	}
}

void GameObject::FixedUpdate(float dt)
{
	if (isDestroyed == true)
	{
		return;
	}
	for (unsigned int i = 0; i < numComponents; i++)
	{
		if (components[i] != nullptr)
		{
			components[i]->FixedUpdate(dt);
		}
	}
}

void GameObject::Draw()
{
	for (unsigned int i = 0; i < numComponents; i++)
	{
		if (components[i] != nullptr)
		{
			components[i]->Draw();
		}
	}
}

void GameObject::AddComponent(Component * component)
{
	component->SetParent(this);
	components[numComponents] = component;
	numComponents += 1;
}

Component * GameObject::GetComponent(const std::string & names)
{
	for (unsigned int i = 0; i < numComponents; i++)
	{
		if (components[i]->GetName() == names)
		{
			return components[i];
		}
	}
	return nullptr;
}

void GameObject::Destroy()
{
	isDestroyed = true;
}

bool GameObject::IsDestroyed() const
{
	return isDestroyed;
}

Space * GameObject::GetSpace() const
{
	return static_cast<Space*>(GetParent());
}
