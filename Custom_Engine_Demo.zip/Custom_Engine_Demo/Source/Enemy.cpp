/*
File: Enemy.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Enemy.h and implements functions that
clones the enemy, initializes the enemy, updates the enemy, sets the next state of the
enemy, sets the enemy map collision handler
*/
#include "stdafx.h"
#include "Enemy.h"
#include "Space.h"
#include "Transform.h"
#include "Physics.h"
#include "GameObjectManager.h"
#include "Collider.h"
#include <iostream>

void Behaviors::EnemyMapCollisionHandler(GameObject& object, const MapCollision& collision);

enum EnemyStates
{
	StateIdle,
	StateWander,
	StateChase
};

Behaviors::Enemy::Enemy()
	: Component("Enemy"), currentState(StateIdle), nextState(StateIdle), innerState(InnerStateEnter), timer(0), stateChangeTime(0.f)
{
}

Component * Behaviors::Enemy::Clone() const
{
	return new Enemy(*this);
}

void Behaviors::Enemy::Initialize()
{
	transform = static_cast<Transform*>(GetOwner()->GetComponent("Transform"));
	physics = static_cast<Physics*>(GetOwner()->GetComponent("Physics"));
	static_cast<Collider*>(GetOwner()->GetComponent("Collider"))->SetMapCollisionHandler(EnemyMapCollisionHandler);
}

void Behaviors::Enemy::Update(float dt)
{
	Transform* monkeyTransform = static_cast<Transform*>(GetOwner()->GetSpace()->GetObjectManager().GetObjectByName("monkey")->GetComponent("Transform"));
	Vector2D walkSpeed = Vector2D(40.f, 0.f);
	Vector2D chaseSpeed = Vector2D(100.f, 0.f);
	float distance = 200.f;
	float snapDistance = 5.f;
	switch (currentState)
	{
	case StateIdle:
	{
		switch (innerState)
		{
		case InnerStateEnter:
			innerState = InnerStateUpdate;
			break;
		case InnerStateUpdate:
			if (AlmostEqual(monkeyTransform->GetTranslation().x, transform->GetTranslation().x, snapDistance))
			{
				physics->SetVelocity(Vector2D(0, 0));
				innerState = InnerStateExit;
				nextState = StateIdle;
				break;
			}
			else
			{
				innerState = InnerStateExit;
				nextState = StateWander;
				break;
			}
		case InnerStateExit:
			currentState = nextState;
			innerState = InnerStateEnter;
			break;
		}
		break;
	}
	case StateWander:
		switch (innerState)
		{
		case InnerStateEnter:
			physics->SetVelocity(-walkSpeed);
			innerState = InnerStateUpdate;
			break;
		case InnerStateUpdate:
			if (monkeyTransform->GetTranslation().Distance(transform->GetTranslation()) <= distance)
			{
				innerState = InnerStateExit;
				nextState = StateChase;
			}
			break;
		case InnerStateExit:
			currentState = nextState;
			innerState = InnerStateEnter;
			break;
		}
		break;

	case StateChase:
		switch (innerState)
		{
		case InnerStateEnter:
			innerState = InnerStateUpdate;
			break;
		case InnerStateUpdate:
			if (AlmostEqual(monkeyTransform->GetTranslation().x, transform->GetTranslation().x, snapDistance))
			{
				innerState = InnerStateExit;
				nextState = StateIdle;
			}
			else if (monkeyTransform->GetTranslation().x < transform->GetTranslation().x)
			{
				physics->SetVelocity(-chaseSpeed);
			}
			else if (monkeyTransform->GetTranslation().x > transform->GetTranslation().x)
			{
				physics->SetVelocity(chaseSpeed);
			}
			else if (monkeyTransform->GetTranslation().Distance(transform->GetTranslation()) > distance)
			{
				innerState = InnerStateExit;
				nextState = StateIdle;
			}
		case InnerStateExit:
			currentState = nextState;
			innerState = InnerStateEnter;
			break;
		}
		break;
	}
	timer += dt;
}

void Behaviors::Enemy::SetState(unsigned nextStates)
{
	nextState = nextStates;
}

void Behaviors::EnemyMapCollisionHandler(GameObject & object, const MapCollision & collision)
{
	Vector2D walkSpeed = Vector2D(30.f, 0.f);
	if (static_cast<Enemy*>(object.GetComponent("Enemy"))->currentState == StateWander)
	{
		if (collision.left == true)
		{
			static_cast<Physics*>(object.GetComponent("Physics"))->SetVelocity(walkSpeed);
		}
		if (collision.right == true)
		{
			static_cast<Physics*>(object.GetComponent("Physics"))->SetVelocity(-walkSpeed);
		}
	}
}