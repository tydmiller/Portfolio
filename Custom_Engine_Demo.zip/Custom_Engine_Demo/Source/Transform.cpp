/*
File: Transform.cpp
Name: Tyler Miller
Course: CS230
Date: 11-7-18
Description: This implements the functions from Transform.h and implements functions that
gets the matrix, sets the translation, sets the rotation, gets the rotation, sets the scale,
gets the scale, and calculates matrices
*/
#include "stdafx.h"
#include "Transform.h"
#include "Matrix2DStudent.h"

Transform::Transform(float x, float y)
	: Component("Transform"), translation(x,y), isDirty(true)
{
}

Transform::Transform(Vector2D translation, Vector2D scale, float rotation)
	: Component("Transform"), translation(translation), scale(scale), rotation(rotation), isDirty(true)
{
}

Component * Transform::Clone() const
{
	return new Transform(*this);
}

const CS230::Matrix2D & Transform::GetMatrix()
{
	CalculateMatrices();
	return matrix;
}

const CS230::Matrix2D & Transform::GetInverseMatrix()
{
	CalculateMatrices();
	return inverseMatrix;
}

void Transform::SetTranslation(const Vector2D & translations)
{
	if (AlmostEqual(translations, translation) == false)
	{
		isDirty = true;
	}
	translation = translations;
}

const Vector2D & Transform::GetTranslation() const
{
	return translation;
}

void Transform::SetRotation(float rotations)
{
	if (AlmostEqual(rotations, rotation) == false)
	{
		isDirty = true;
	}
	rotation = rotations;
}

float Transform::GetRotation() const
{
	return rotation;
}

void Transform::SetScale(const Vector2D & scales)
{
	if (AlmostEqual(scales, scale) == false)
	{
		isDirty = true;
	}
	scale = scales;
}

const Vector2D & Transform::GetScale() const
{
	return scale;
}

void Transform::CalculateMatrices()
{
	if (isDirty == true)
	{
		CS230::Matrix2D translationMatrix = CS230::Matrix2D::TranslationMatrix(translation.x, translation.y);
		CS230::Matrix2D rotationMatrix = CS230::Matrix2D::RotationMatrixRadians(rotation);
		CS230::Matrix2D scalingMatrix = CS230::Matrix2D::ScalingMatrix(scale.x, scale.y);
		CS230::Matrix2D inverseTranslationMatrix = CS230::Matrix2D::TranslationMatrix(-translation.x, -translation.y);
		CS230::Matrix2D inverseRotationMatrix = CS230::Matrix2D::RotationMatrixRadians(-rotation);
		CS230::Matrix2D inverseScalingMatrix = CS230::Matrix2D::ScalingMatrix(1 / scale.x, 1 / scale.y);
		matrix = translationMatrix * rotationMatrix * scalingMatrix;
		inverseMatrix = inverseScalingMatrix * inverseRotationMatrix * inverseTranslationMatrix;
		isDirty = false;
	}
}
