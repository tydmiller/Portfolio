/*
File: ColliderCircle.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from ColliderCircle.h and implements functions that
clones the collider circle, draws collider circle, and is colliding with collider circle functions
*/
#include "stdafx.h"
#include "ColliderCircle.h"
#include "Space.h"
#include "DebugDraw.h"
#include "Graphics.h"
#include "Transform.h"
#include "Intersection2D.h"
#include "ColliderRectangle.h"
#include "ColliderPoint.h"

ColliderCircle::ColliderCircle(float radius)
	: Collider(ColliderTypeCircle), radius(radius)
{
}

Component * ColliderCircle::Clone() const
{
	return new ColliderCircle(*this);
}

void ColliderCircle::Draw()
{
	DebugDraw& draw = DebugDraw::GetInstance();
	Graphics& graphics = Graphics::GetInstance();
	draw.AddCircle(transform->GetTranslation(), radius, graphics.GetDefaultCamera(), Colors::Green);
}

float ColliderCircle::GetRadius() const
{
	return radius;
}

void ColliderCircle::SetRadius(float radii)
{
	radius = radii;
}

bool ColliderCircle::IsCollidingWith(const Collider & other) const
{
	if (other.GetType() == ColliderTypeCircle)
	{
		const ColliderCircle& otherCircle = static_cast<const ColliderCircle&>(other);
		return CircleCircleIntersection(Circle(static_cast<Transform*>(GetOwner()->GetComponent("Transform"))->GetTranslation(), GetRadius()), Circle(static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation(), otherCircle.GetRadius()));
	}
	if (other.GetType() == ColliderTypePoint)
	{
		//const ColliderPoint& otherPoint = static_cast<const ColliderPoint&>(other);
		return PointCircleIntersection(Vector2D(static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation()), Circle(static_cast<Transform*>(GetOwner()->GetComponent("Transform"))->GetTranslation(), GetRadius()));
	}
	if (other.GetType() == ColliderTypeRectangle)
	{
		const ColliderRectangle& otherRectangle = static_cast<const ColliderRectangle&>(other);
		return RectangleCircleIntersection(BoundingRectangle(static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation(), otherRectangle.GetExtents()), Circle(static_cast<Transform*>(GetOwner()->GetComponent("Transform"))->GetTranslation(), GetRadius()));
	}
	return false;
}
