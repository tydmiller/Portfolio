/*
File: Component.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from Component.h and implements functions that
Gets the owner
*/
#include "stdafx.h"
#include "Component.h"
#include "GameObject.h"

Component::Component(const std::string & name)
	: BetaObject(name)
{
}

GameObject * Component::GetOwner() const
{
	return static_cast<GameObject*>(GetParent());
}
