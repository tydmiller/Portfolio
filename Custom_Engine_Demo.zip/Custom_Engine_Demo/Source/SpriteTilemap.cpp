/*
File: SpriteTilemap.cpp
Name: Tyler Miller
Course: CS230
Date: 11-7-18
Description: This implements the functions from SpriteTilemap.h and implements functions that
clone, draw, set tile map
*/
#include "stdafx.h"
#include "SpriteTilemap.h"
#include "Tilemap.h"
#include "Transform.h"
#include "Sprite.h"

SpriteTilemap::SpriteTilemap()
	: Sprite(), map(nullptr)
{
}

Component * SpriteTilemap::Clone() const
{
	return new SpriteTilemap(*this);
}

void SpriteTilemap::Draw()
{
	int width = map->GetWidth();
	int height = map->GetHeight();
	Vector2D scale = transform->GetScale();
	for (int r = 0; r < height; ++r)
	{
		for (int c = 0; c < width; ++c)
		{
			int mapCellValue = map->GetCellValue(c, r);
			if (mapCellValue == 0)
			{
				continue;
			}
			SetFrame(mapCellValue - 1);
			Vector2D offset = Vector2D(c * scale.x, r * -scale.y);
			Sprite::Draw(offset);
		}
	}
}

void SpriteTilemap::SetTilemap(const Tilemap * maps)
{
	map = maps;
}
