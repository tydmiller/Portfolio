/*
File: ScreenWrap.cpp
Name: Tyler Miller
Date: 10-11-18
Course: CS230
Description: This has all the implementation for ScreenWrap.h and
			 implements the clone of screen wrap, intialize screen wrap,
			 and updates screen wrap
*/
#include "stdafx.h"
#include "ScreenWrap.h"
#include "Graphics.h"
#include "Input.h"		// CheckTriggered
#include "Space.h"		// GetStateManager
#include "Vertex.h"		 // Vertex
#include "Texture.h"    //Texture
#include "GameObject.h"	// GameObjectCreate, GameObjectUpdate, etc.
#include "Vector2D.h"	// Vector2D
#include "Transform.h"	// Transform
#include "Sprite.h"		// Sprite
#include "SpriteSource.h" //SpriteSource
#include "Physics.h"
#include "Animation.h"
#include "GameObjectManager.h"
#include "System.h"
#include "PlayerShip.h"
#include "TimedDeath.h"

Behaviors::ScreenWrap::ScreenWrap()
	: Component("ScreenWrap"), transform(transform), physics(physics)
{
}

Component * Behaviors::ScreenWrap::Clone() const
{
	return new ScreenWrap(*this);
}

void Behaviors::ScreenWrap::Initialize()
{
	transform = static_cast<Transform*>(GetOwner()->GetComponent("Transform"));
	physics = static_cast<Physics*>(GetOwner()->GetComponent("Physics"));
}

void Behaviors::ScreenWrap::Update(float dt)
{
	UNREFERENCED_PARAMETER(dt);
	Graphics& graphics = Graphics::GetInstance();
	Vector2D playerTranslation = transform->GetTranslation();
	Vector2D playerScale = transform->GetScale();
	Vector2D playerVelocity = physics->GetVelocity();
	BoundingRectangle screen = graphics.GetScreenWorldDimensions();
	if (playerTranslation.x > screen.right + playerScale.x)
	{
		transform->SetTranslation(Vector2D(screen.left - playerScale.x, playerTranslation.y));
	}
	if (playerTranslation.x < screen.left - playerScale.x)
	{
		transform->SetTranslation(Vector2D(screen.right + playerScale.x, playerTranslation.y));
	}
	if (playerTranslation.y > screen.top + playerScale.y)
	{
		transform->SetTranslation(Vector2D(playerTranslation.x, screen.bottom - playerScale.y));
	}
	if (playerTranslation.y < screen.bottom - playerScale.y)
	{
		transform->SetTranslation(Vector2D(playerTranslation.x, screen.top + playerScale.y));
	}
}
