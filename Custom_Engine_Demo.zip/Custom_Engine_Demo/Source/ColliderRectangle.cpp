/*
File: ColliderRectangle.cpp
Name: Tyler Miller
Course: CS230
Date: 10-22-18
Description: This implements the functions from ColliderRectangle.h and implements functions that
clone collider rectangle, draw collider rectangle, get extents on collider rectangle, sets extents
on collider rectangle, and is colliding with functions
*/
#include "stdafx.h"
#include "ColliderRectangle.h"
#include "Space.h"
#include "DebugDraw.h"
#include "Graphics.h"
#include "Transform.h"
#include "Intersection2D.h"
#include "ColliderPoint.h"
#include "ColliderCircle.h"

ColliderRectangle::ColliderRectangle(const Vector2D & extents)
	: Collider(ColliderTypeRectangle), extents(extents)
{
}

Component * ColliderRectangle::Clone() const
{
	return new ColliderRectangle(*this);
}

void ColliderRectangle::Draw()
{
	DebugDraw& draw = DebugDraw::GetInstance();
	Graphics& graphics = Graphics::GetInstance();
	draw.AddRectangle(transform->GetTranslation(), extents, graphics.GetDefaultCamera(), Colors::Green);
}

const Vector2D & ColliderRectangle::GetExtents() const
{
	return extents;
}

void ColliderRectangle::SetExtents(const Vector2D & moreExtents)
{
	extents = moreExtents;
}

bool ColliderRectangle::IsCollidingWith(const Collider & other) const
{
	if (other.GetType() == ColliderTypeRectangle)
	{
		const ColliderRectangle& otherRectangle = static_cast<const ColliderRectangle&>(other);
		return RectangleRectangleIntersection(BoundingRectangle(static_cast<Transform*>(GetOwner()->GetComponent("Transform"))->GetTranslation(), GetExtents()), BoundingRectangle(static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation(), otherRectangle.GetExtents()));
	}
	else if (other.GetType() == ColliderTypeCircle)
	{
		const ColliderCircle& otherCircle = static_cast<const ColliderCircle&>(other);
		return RectangleCircleIntersection(BoundingRectangle(static_cast<Transform*>(GetOwner()->GetComponent("Transform"))->GetTranslation(), GetExtents()), Circle(static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation(), otherCircle.GetRadius()));
	}
	else if (other.GetType() == ColliderTypePoint)
	{
		return PointRectangleIntersection(static_cast<Transform*>(other.GetOwner()->GetComponent("Transform"))->GetTranslation(), BoundingRectangle(static_cast<Transform*>(GetOwner()->GetComponent("Transform"))->GetTranslation(), GetExtents()));
	}
	if (other.GetType() == ColliderTypeTilemap)
	{
		return other.IsCollidingWith(*this);
	}
	return false;
}
